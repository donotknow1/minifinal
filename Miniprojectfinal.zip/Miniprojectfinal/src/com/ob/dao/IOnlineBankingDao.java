package com.ob.dao;

import java.sql.SQLException;
import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;


public interface IOnlineBankingDao {

	abstract CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException;
	abstract NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException;
	abstract void Request(int acc_id, String description) throws OnlineBankingException;
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException;
	abstract int customerSignUp(CustomerSignUp obs) throws OnlineBankingException;
	abstract int updateLoginPassword(int accountid,String loginPassword) throws OnlineBankingException;
	abstract int serviceTrackerId(int accountId) throws OnlineBankingException;
	abstract void Request1(int accountId, String description) throws OnlineBankingException;
	abstract int Request3(int accountId, String description) throws OnlineBankingException;
	abstract List<Transaction> getMonthlyTransactions(int month) throws SQLException;
	abstract List<Transaction> getYearlyTransactions(int year) throws SQLException;
	abstract List<Transaction> retrieveAllTranInfo() throws SQLException;
	abstract int addinfo(NewAccount newAccount) throws OnlineBankingException;
	abstract List<Transaction> getDayTransactions(int day) throws SQLException;
	abstract void updatepayeraccountbal(int transactionAmount);
	abstract String retrivetransactionpwd(int accountId);
	abstract int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException;
	abstract int checkpayeeAccountId(int payeeAccountId);
	abstract List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException;
	abstract void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount);
	abstract void updatepayeeaccountbal(int transactionAmount);
	abstract void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string);
	
	
	

	

	
	
	
	
	
	

	
	
	

	

	

}
