package com.ob.dao;

public interface IQueryMapper {
     // Account Master
    String ACCOUNT_MASTER_INSERT_QRY="INSERT into AccountMaster values(ac_seq1.NEXTVAL,?,?,SYSDATE)";
    String RETRIVE_BY_AccountID_QRY="SELECT AccountId from Account where AccountId=? ";
    //Customer Master
     String Customer_INSERT_QRY="INSERT into Customer values(ac_seq1.CURRVAL,?,?,?,?,?,?,?)";
     String RETRIVE_BY_CustomerID_QRY="SELECT CoustomerId from Customer where CustomerId=? ";
     String CUSTOMER_update_Qry="Update table customer set  customeraddress=newAddress where id=?)";
     String CUSTOMER_updatemobile_Qry="Update table customer set  customermobnum=newMobileNumber where id=?)";
     String RETRIVE_BY_OPENINGBAL_QRY="SELECT openingbalance from customer where accountid=?";
    //Transaction 
     /* String Transaction_INSERT_QRY="INSERT into Transaction values(ts_seq.NEXTVAL,?,?,?,?,?)";
      String RETRIVE_BY_TransactionID_QRY="SELECT TransactionId from Transaction where TransactionId=?";*/
      //Service Tracker
      String ServiceTracker_INSERT_QRY="INSERT into ServiceTracker values(st_seq.NEXTVAL,?,ac_seq1.CURRVAL,sysdate,active)";

      String RETRIVE_BY_ServiceTrackerID_QRY="SELECT ServiceTrackerId from ServiceTracker where  ServiceTrackerId=?";
     //usertable
      String Usertable_INSERT_QRY=" insert into user_table values(?,?,?,?,?,?)";
      String RETRIVE_BY_UserID_QRY="SELECT * from user_table where  user_id=? and LOGIN_PASSWORD=?";
      
     // fund_transfer
      String fundTransfer_INSERT_QRY="INSERT into fund_transfer values(ft_seq1.NEXTVAL,ac_seq1.CURRVAL,?,SYSDATE,?)";
      String RETRIVE_BY_fundTransfeID_QRY="SELECT ServiceTrackerId from fund_transfer where  fundTransferId=?";
     // payee table
      String payee_table_Qry="Select * from payeeTable";
      //transactions table
      String insert_qry = "insert into customer values(?,?,?,?,?,?,seq.nextval,?)";
  	  String retrieve_month = "SELECT * FROM transactions WHERE to_char(dateoftransaction,'MM') = ?";
  	  String retrieve_day ="SELECT * FROM transactions WHERE to_char(dateoftransaction,'DD') = ?";
  	  String retrieve_year ="SELECT * FROM transactions WHERE to_char(dateoftransaction,'YYYY') = ?";
  	  String retrieveall = "SELECT * FROM transactions ";
  	  
      String Update_PASSWORD="update user_table set loginPassword=? where accountId=?";
	  String RETRIVE_PAYEE_ID="select payee_account_id,nickname from payee where account_id=?";
	  String PAYEE_INSERT_QRY = "insert into payee values(?,?,?)";
      }
	


