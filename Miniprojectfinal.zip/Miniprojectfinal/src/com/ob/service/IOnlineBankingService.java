package com.ob.service;

import java.sql.SQLException;
import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;


public interface IOnlineBankingService<Payee> {
	
	abstract CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException;
	abstract NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException;
	abstract void Request(int acc_id, String description) throws OnlineBankingException;
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException;
	abstract int updateLoginPassword(int accountid,String loginPassword) throws OnlineBankingException;
	abstract int customerSignUp(CustomerSignUp csu) throws OnlineBankingException;
	boolean validateUserId(int userId);
	boolean validateLoginPassword(String loginPassword);
	boolean validateSecretQuestion(String secretQuestion);
	boolean validateTransactionPassword(String transactionPassword);
	abstract int serviceTrackerId(int accountId) throws OnlineBankingException;
	abstract boolean validatename(String name);
	abstract boolean validatemobileNo(String mobileNo);
	abstract boolean validatePanCard(String panCard);
	abstract boolean validateAccountType(String accountType);
	abstract boolean validateEMail(String eMail);
	abstract boolean validateOpeningBalance(int openingBalance);
	abstract int addinfo(NewAccount newAccount) throws OnlineBankingException;
	abstract List<Transaction> retrieveAllTranInfo() throws SQLException;
	abstract List<Transaction> getMonthlyTransactions(int month) throws SQLException;
	abstract List<Transaction> getDayTransactions(int day) throws SQLException;
	abstract List<Transaction> getYearlyTransactions(int year) throws SQLException;
	abstract void Request1(int accountId, String description) throws OnlineBankingException;
	abstract int Request3(int accountId, String description) throws OnlineBankingException;
	abstract void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string);
	abstract void updatepayeeaccountbal(int transactionAmount);
	abstract void updatepayeraccountbal(int transactionAmount);
	abstract void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount);
	abstract String retrivetransactionpwd(int accountId);
	abstract int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException;
	abstract int checkpayeeAccountId(int payeeAccountId);
	abstract List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException;
	
}
