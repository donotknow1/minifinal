package com.ob.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class OnlineBanking {
	 static Scanner sc=null;
	 static IOnlineBankingService serobj;
	 static CustomerSignUp csu=null;
	static int openingBalance=0;
	public OnlineBanking() {
		serobj=new OnlineBankingService();
		csu=new CustomerSignUp();
	}
	
	/*  main program  */
	public static void main(String[] args) throws OnlineBankingException, SQLException {
		
		sc=new Scanner(System.in);
		/* do while loop for infity  */
Logger log = Logger.getRootLogger();
		
		System.out.println("**********WELCOME TO ABC BANK***********");
		System.out.println("");
		System.out.println("          1.Account Holder              ");
		System.out.println("          2.Admin                       ");
		System.out.println("****************************************");
		System.out.println("Enter your option:");
		 int option=sc.nextInt();
		
		switch (option) {
		case 1://Get login details
			log.info(option);
			System.out.println("1.SignIn");
		    System.out.println("2.Signup");
			System.out.println("Enter your choice:");
			 int choice=sc.nextInt();
			  switch (choice) {
			  
			case 1://Signin 
				log.info(choice);
				System.out.println("Login id:");
				String loginid=sc.next();
				System.out.println("Password:");
				String pass=sc.next();
				customerLoginPage();
			break;
			case 2: //signup
			
				 System.out.println("SIGN UP");
			     String custsignup=sc.nextLine();
			     customerSignUp();
			
			  break;
			 }	
			// Admin  login details
		case 2:
			System.out.println("ENTER YOUR USERID");
			int adminuserid=sc.nextInt();
			
			System.out.println("ENTER YOUR PASSWORD");
			String adminpassword=sc.next();
		
			if((adminuserid==1234) && (adminpassword.equals("admin"))) 
			{
			administrationLogin();
			
			}
			else {
				System.out.println("ENTER VALID LOGIN DETAILS");
				
			}
			default:
			System.out.println("Enter Valid details");
		
		}
	}
	private static void administrationLogin() throws SQLException, OnlineBankingException {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1.CREATE NEW ACCOUNT");
		System.out.println("2.VIEW TRANSACTION");
		int adminoption=sc.nextInt();
		boolean result=true;
		
		String mobileNo;
		String eMail;
		int openingBalance;
		String panCard;
		String accountType;
		
		switch (adminoption) {
		case 1:				
			System.out.println("PLEASE ENTER  DETAILS");
			String name;
			do {
			System.out.println("ENTER YOUR NAME ");
		     name=sc.next();
			
			}while(serobj.validatename(name)==false);
			
			System.out.println("ENTER ADDRESS DETAILS");
			String addressDetails=sc.next();
		
			do {
			System.out.println("ENTER MOBILE NUMBER");
			mobileNo=sc.next();
			
			}while(serobj.validatemobileNo(mobileNo)==false);
			
		do {
			System.out.println("ENTER EMAIL ID");
			 eMail=sc.next();
			
		}while(serobj.validateEMail(eMail)==false);
			
		do {
			System.out.println("OPENING BALANCE");
		 openingBalance=sc.nextInt();
			
		}while(serobj.validateOpeningBalance(openingBalance)==false);
		
		do {
			System.out.println("ENTER pan card");
			 panCard=sc.next();
			
		}while(serobj.validatePanCard(panCard)==false);
			
		do {
			System.out.println("enter account type");
			 accountType=sc.next();
			serobj.validateAccountType(accountType);
		}while(serobj.validateAccountType(accountType)==false);
			
			
			int accountId=0;
			NewAccount newAccount= new NewAccount(accountId, name, eMail,mobileNo, addressDetails, accountType, openingBalance, panCard);
		
			int result1=addinfo(newAccount);				
			
			System.out.println("WELCOME TO ABC BANK");
			
			break;
        
			  
        case 2:
        	System.out.println("enter value to see the transaction details ");
        	System.out.println(" 1.FOR 1 DAY ");
        	System.out.println(" 2.FOR 1 MONTH ");
        	System.out.println(" 3.FOR 1 YEAR ");
        	System.out.println(" 4.ALL TRANSACTION");
        	int choice1=sc.nextInt();
        	switch (choice1) {
        	case 1:
        		System.out.println("Enter the day to get transaction");
			       int day=sc.nextInt();
			       List<Transaction> finList2= new ArrayList<>();
					finList2 = getDayTransactions(day);
					for (Transaction tran : finList2) {
						System.out.println(tran);
					}

                 
            case 2:
				 System.out.println("enterr the month to get tran");
			       int month=sc.nextInt();
			       List<Transaction> finList= new ArrayList<>();
				
						finList = getMonthlyTransactions(month);
						for (Transaction tran : finList) {
							System.out.println(tran);
						}
						
				break;
			 case 3:
				System.out.println("enterr the year to get tran");
			       int year=sc.nextInt();
			       List<Transaction> finList3= new ArrayList<>();
					
					finList3 = getYearlyTransactions(year);
					for (Transaction tran : finList3) {
						System.out.println(tran);
					}
			       
               break;
			 case 4:
				List<Transaction> finList1=null;
				
					finList1 = retrieveAllTranInfo();			
			
				for(Transaction tran:finList1)
				{
				System.out.println(tran);	
				}
			     
            break;
			default:
				break;
			}   	
				
		}
		
		
	}
	private static List<Transaction> getYearlyTransactions(int year) throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.getYearlyTransactions(year);
	}
	private static List<Transaction> getDayTransactions(int day) throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.getDayTransactions(day);
		
	}
	private static List<Transaction> getMonthlyTransactions(int month) throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.getMonthlyTransactions(month);
	}
	private static List<Transaction> retrieveAllTranInfo() throws SQLException {
		serobj=new OnlineBankingService();
		return serobj.retrieveAllTranInfo() ;
	}
	private static int addinfo(NewAccount newAccount) throws OnlineBankingException {
		serobj=new OnlineBankingService();
		return serobj.addinfo(newAccount);
	}
		
	
	public static void customerLoginPage() throws OnlineBankingException {
		     int accountId=0;
	         customerLogin(accountId);
		     System.out.println("PLEASE ENTER CORRECT OPTION");
			
		}
     private static CustomerSignUp validateCustomerLoginDetails(int custuserid,String custpassword) throws OnlineBankingException {
		serobj=new OnlineBankingService();
		
		return serobj.validateCustomerLoginDetails(custuserid, custpassword);
	}

	 public static void customerLogin(int accountId) throws OnlineBankingException {
		
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1.ACCOUNT BALANCE");
		//System.out.println("2.MINI/DETAILED STATEMENTS");
		System.out.println("3.ADDRESS CHANGE REQUEST");
		System.out.println("4.MOBILE NO. CHANGE REQUEST");
		System.out.println("5.CHEQUE BOOK REQUEST");
		System.out.println("6.SERVICE REQUEST TRACKER");
		//System.out.println("7.FUND TRANSFER");
		System.out.println("8.CHANGE PASSWORD");
		
		int custoption=sc.nextInt();
		
		String description=null;
		switch (custoption) {
		
		case 1:
		    NewAccount accbal=serobj.customerOpeningBalance(accountId);
			System.out.println("YOUR ACCOUNT BALANCE  :  "+accbal);
			break;
			
        case 2:
        	/*     mini and detailed transaction    */
			
			break;
			
        case 3:
        	System.out.println("ENTER YOUR NEW ADDRESS");
        	description=sc.next();
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	        break;
	        
        case 4:
        	System.out.println("ENTER YOUR NEW MOBILE NUMBER");
        	description=sc.next();
        	serobj.Request1(accountId,description);
            System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 5:
        	int acc_id=serobj.serviceTrackerId(accountId);
        	description="NEW CHEQUEBOOK";
        	serobj.Request3(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 6:
        	List<ServiceTracker> servicetracker=null;
			
				servicetracker = serobj.retrieveServiceTrackerByAccountId(accountId);
		
			
			for(ServiceTracker st:servicetracker)
			{
			System.out.println(st);	
			}
	 
	        break;
        case 7: 
	        List<Payee> payeelist=serobj.retrivePayeeDetails(accountId);         /*       from payee table       */
       	 for(Payee p:payeelist) {
       		 System.out.println(p);
       	 }
       	 System.out.println("ENTER THE PAYEE ACCOUNT ID");
       	 int payeeaccountid=sc.nextInt();
       	 int a=0;
       	 for(Payee l:payeelist) {
       		 if(payeeaccountid==l.getAccountId()) {
       			 a=10;
       			 transaction(accountId,payeeaccountid);
       		 }
       	 }
       	 if(a!=10) {
       		 System.out.println("REGISTER NEW PAYEE ACCOUNT");
       		 System.out.println("ENTER THE PAYEE ACCOUNT ID");
       		 int payeeAccountId=sc.nextInt();
       		 int result=serobj.checkpayeeAccountId( payeeAccountId);    /*       search in account master table      */
       		 
       		 if(result>0) {
       		 System.out.println("ENTER NICKNAME");
       		 String nickname=sc.next();
       		 int status=serobj.storepayeeDetails(accountId,payeeAccountId,nickname);     /*       to payee details        */
       		 
       		 if(status>0) {
       			 System.out.println("data enter successfully");
       		 }else {
       			 System.out.println("data not entered");
       		 }
       		 
       		 
       		 }else {
       			 System.out.println("ENTERED THE WRONG ACCCOUNT ID");
       		 }
       		 
       	 }
       	 
     
      	 
	        break;
	     
       
       case 8:
       	System.out.println("CHANGE PASSWORD FOR USERLOGIN");
       	int count=0;
       	do {
       	System.out.println("ENTER YOUR ACCOUNT ID");
       	int acid=sc.nextInt();
       	
       	if(accountId==acid){
       		String loginPassword;
       		do{
       		System.out.println("ENTER NEW PASSWORD");
       	    loginPassword=sc.next();
       		}while(serobj.validateLoginPassword(loginPassword)==false);
       		count=3;
       		int custuserid=0;
			serobj.updateLoginPassword(custuserid,loginPassword);
       	}else {
       		System.err.println("ENTER CORRECT ACCOUNT ID");
       		count++;
       	}
       	}while(count<=3);
       	
       	
       	/*    provide  status       */
	
	        break;
       
		default:
			break;
		}
		
		
	}
	
	
public static void customerSignUp() throws OnlineBankingException {
		
		 csu=new CustomerSignUp();
		 serobj=new OnlineBankingService();
		
		System.out.println("ENTER THE ACCOUNT ID");
		int accountId=sc.nextInt();
		csu.setAccountId(accountId);
		
		System.out.println("CREATE USER NAME");
		int userId=sc.nextInt();
		csu.setUserId(userId);
		
		System.out.println("CREATE PASSWORD");
		String loginPassword=sc.next();
		csu.setLoginPassword(loginPassword);
		
		System.out.println("SECRET QUESTION --> WHEN DO YOU GET HIGH ?");
		String secretQuestion=sc.next();
		csu.setSecretQuestion(secretQuestion);
		
		System.out.println("CREATE TRANSACTION PASSWORD");
		String transactionPassword=sc.next();
		csu.setTransactionPassword(transactionPassword);
		
		System.out.println("CREATE LOCK STATUS ****************************");
		String lockStatus=sc.next();
		csu.setLockStatus(lockStatus);
		int out=serobj.customerSignUp(csu);
		if(out>0) {
			System.out.println("data is inserterd");
		}
}
		public static void transaction(int accountId,int payeeaccountid){
			String transpwd=null;
	    	System.out.println("ENTER THE TRANSACTION PASSWORD");
	    	transpwd=sc.next();                 
	    	String usertransactionpwd=serobj.retrivetransactionpwd(accountId);
	    	if(transpwd==usertransactionpwd&&transpwd!=null) {
	    		
	  
	    	System.out.println("ENTER THE AMOUNT");
	    	int transactionAmount=sc.nextInt();           /*      AMOUNT SHOULD BE LESS THAN 10 LAKHS ( take it easy )   */
	    	
	    	int transaction_id=(int)(Math.random()*1000000);
	    	System.out.println("ENTER THE TRANSACTION DESCRIPTION");
	    	String transdesc=sc.next();
	    	System.out.println("TRANSACTION TYPE");
	    	System.out.println(" 1  --->  NEFT");
	    	System.out.println(" 2  --->  RTGS");
	    	System.out.println(" 3  --->  IMPS");
	    	int choice=sc.nextInt();
	    	switch (choice) {
	    	
			case 1:
			    serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"NEFT");    /*  to transaction table */  
				serobj.updatepayeeaccountbal(transactionAmount);                                  /*   to account master    */
				serobj.updatepayeraccountbal(transactionAmount);                                /*    to account master     */
				serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);   /*  to fund transfer table */
				
				System.out.println("NEFT TRANSACTION SUCCESSFUL");
				
				break;
				
				
			case 2:
				serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"RTGS");              
				serobj.updatepayeeaccountbal(transactionAmount);
				serobj.updatepayeraccountbal(transactionAmount);
				serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
				System.out.println("RTGS TRANSACTION SUCCESSFUL");
				break;
				
			case 3:
				serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"IMPS");          
				serobj.updatepayeeaccountbal(transactionAmount);
				serobj.updatepayeraccountbal(transactionAmount);
				serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
				System.out.println("IMPS TRANSACTION SUCCESSFUL");
				break;

			default:
				System.out.println("INVALID CHOICE . PLEASE ENTER CORRECT OPTION");
				break;
			}
	    	
	    	}else {
	    		System.out.println("ENTERED WRONG TRANSACTION PASSWORD");
	    	}
			
		}
	}



